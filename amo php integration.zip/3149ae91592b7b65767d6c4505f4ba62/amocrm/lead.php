﻿<?php
function set_log($message)
{
   $log = date('Y-m-d H:i:s') . ' ' . print_r($message, 1);
   file_put_contents(__DIR__ . '/log.txt', $log . PHP_EOL, FILE_APPEND);
}
set_log($_REQUEST);
require_once __DIR__ . '/vendor/autoload.php';
if (isset($_REQUEST['__submission'])) {
   $data = $_REQUEST['__submission'];
   $userData = $data['user_inputs'];
   $comment = '';
   switch ($data['form_id']) {

      case '4':
         $name = $userData['name'];
         $phone = $userData['phone'];
         $email = $userData['email'];
         $formname = "Зеркала";
         $comment .= 'Описание проекта: ' . $userData['description'] . '
          ';
         $comment .= 'Файл чертежа или примера: ' . $userData['file-upload'] . '
          ';
         $comment .= 'Размеры (В/Г/Д): ' . $userData['size'] . '
          ';
         $comment .= 'Цвет рамы: ' . $userData['cvet_rami'] . '
          ';
         $comment .= 'Индивидуальный цвет рамы(если указан): ' . $userData['glass_color'] . '
          ';
         $comment .= 'Наличие подсветки: ' . $userData['planki'] . '
          ';
         $comment .= 'Количество: ' . $userData['quantity'] . '
          ';
         $comment .= 'Доставка: ' . $userData['dostavka'] . '
          ';
         $comment .= 'Адрес доставки(если указан): ' . $userData['address'] . '
          ';
         $comment .= 'Монтаж: ' . $userData['montaj'] . '
          ';
         $comment .= 'Поместятся ли изделия в лифт, номер этажа и материал стен: ' . $userData['lift_steni'] . '
          ';
         break;
      case '9':
         $name = $userData['name'];
         $phone = $userData['phone'];
         $email = $userData['email'];
         $formname = "Столы на заказ";

         $comment .= 'Описание проекта: ' . $userData['description'] . '
            ';
         $comment .= 'Файл чертежа или примера: ' . $userData['file-upload'] . '
            ';
         $comment .= 'Размеры (В/Г/Д): ' . $userData['size'] . '
            ';
         $comment .= 'Материал столешницы: ' . $userData['material_stoleshnici'] . '
            ';
         $comment .= 'Обработка дерева: ' . $userData['tip_dereva'] . '
            ';
         $comment .= 'Обработка камня: ' . $userData['tip_kamnnya'] . '
            ';
         $comment .= 'Обработка стекла: ' . $userData['tip_stekla'] . '
            ';
         $comment .= 'Цвет стекла: ' . $userData['glass_color'] . '
            ';
         $comment .= 'Фото принт: ' . $userData['photo_print'] . '
            ';
         $comment .= 'Обработка стекла: ' . $userData['cvet_podstolya'] . '
            ';
         $comment .= 'Обработка стекла: ' . $userData['podstolie_color'] . '
            ';
         $comment .= 'Количество: ' . $userData['quantity'] . '
            ';
         $comment .= 'Доставка: ' . $userData['dostavka'] . '
            ';
         $comment .= 'Адрес доставки(если указан): ' . $userData['address'] . '
            ';
         $comment .= 'Монтаж: ' . $userData['montaj'] . '
            ';
         $comment .= 'Поместятся ли изделия в лифт, номер этажа и материал стен: ' . $userData['lift_steni'] . '
            ';
         break;
      case '11':
         $name = $userData['name'];
         $phone = $userData['phone'];
         $email = $userData['email'];
         $formname = "Стеклянные ограждения на заказ";

         $comment .= 'Описание проекта: ' . $userData['description'] . '
            ';
         $comment .= 'Файл чертежа или примера: ' . $userData['file-upload'] . '
            ';
         $comment .= 'Размеры (В/Г/Д): ' . $userData['size'] . '
            ';
         $comment .= 'Толщина стекла: ' . $userData['tolshina_stekla'] . '
            ';
         $comment .= 'Толщина стекла: ' . $userData['tip_stekla'] . '
            ';
         $comment .= 'Цвет металла: ' . $userData['metal_color'] . '
            ';
         $comment .= 'Цвет профиля металла: ' . $userData['cvet_profila_metala'] . '
            ';
         $comment .= 'Подстолье цвет: ' . $userData['podstolie_color_1'] . '
            ';
         $comment .= 'Количество: ' . $userData['quantity'] . '
            ';
         $comment .= 'Доставка: ' . $userData['dostavka'] . '
            ';
         $comment .= 'Адрес доставки(если указан): ' . $userData['address'] . '
            ';
         $comment .= 'Монтаж: ' . $userData['montaj'] . '
            ';
         $comment .= 'Поместятся ли изделия в лифт, номер этажа и материал стен: ' . $userData['lift_steni'] . '
            ';
         break;
      case '12':
         $name = $userData['name'];
         $phone = $userData['phone'];
         $email = $userData['email'];
         $formname = "Стеклянные перегородки на заказ";

         $comment .= 'Описание проекта: ' . $userData['description'] . '
            ';
         $comment .= 'Файл чертежа или примера: ' . $userData['file-upload'] . '
            ';
         $comment .= 'Размеры (В/Г/Д): ' . $userData['size'] . '
            ';
         $comment .= 'Толщина стекла: ' . $userData['tolshina_stekla'] . '
            ';
         $comment .= 'Толщина стекла: ' . $userData['tip_stekla'] . '
            ';
         $comment .= 'Цвет профиля металла: ' . $userData['cvet_profila_metala'] . '
            ';
         $comment .= 'Количество: ' . $userData['quantity'] . '
            ';
         $comment .= 'Доставка: ' . $userData['dostavka'] . '
            ';
         $comment .= 'Адрес доставки(если указан): ' . $userData['address'] . '
            ';
         $comment .= 'Монтаж: ' . $userData['montaj'] . '
            ';
         $comment .= 'Поместятся ли изделия в лифт, номер этажа и материал стен: ' . $userData['lift_steni'] . '
            ';
         break;
      case '13':
         $name = $userData['name'];
         $phone = $userData['phone'];
         $email = $userData['email'];
         $formname = "Стеклянные двери на заказ";

         $comment .= 'Описание проекта: ' . $userData['description'] . '
            ';
         $comment .= 'Файл чертежа или примера: ' . $userData['file-upload'] . '
            ';
         $comment .= 'Размеры (В/Г/Д): ' . $userData['size'] . '
            ';
         $comment .= 'Толщина стекла: ' . $userData['tolshina_stekla'] . '
            ';
         $comment .= 'Толщина стекла: ' . $userData['tip_stekla'] . '
            ';
         $comment .= 'Цвет профиля металла: ' . $userData['cvet_profila_metala'] . '
            ';
         $comment .= 'Количество: ' . $userData['quantity'] . '
            ';
         $comment .= 'Доставка: ' . $userData['dostavka'] . '
            ';
         $comment .= 'Адрес доставки(если указан): ' . $userData['address'] . '
            ';
         $comment .= 'Монтаж: ' . $userData['montaj'] . '
            ';
         $comment .= 'Поместятся ли изделия в лифт, номер этажа и материал стен: ' . $userData['lift_steni'] . '
            ';
         break;
      case '14':
         $name = $userData['name'];
         $phone = $userData['phone'];
         $email = $userData['email'];
         $formname = "Стекольная продукция на заказ";

         $comment .= 'Описание проекта: ' . $userData['description'] . '
            ';
         $comment .= 'Файл чертежа или примера: ' . $userData['file-upload'] . '
            ';
         $comment .= 'Доставка: ' . $userData['dostavka'] . '
            ';
         $comment .= 'Адрес доставки(если указан): ' . $userData['address'] . '
            ';
         $comment .= 'Монтаж: ' . $userData['montaj'] . '
            ';
         $comment .= 'Поместятся ли изделия в лифт, номер этажа и материал стен: ' . $userData['lift_steni'] . '
            ';
         $comment .= 'Описание проекта: ' . $userData['description'] . '
            ';
         break;
      case '16':
         $name = $userData['name'];
         $phone = $userData['phone'];
         $email = $userData['email'];
         $formname = "Стеллажи и полки на заказ";

         $comment .= 'Описание проекта: ' . $userData['description'] . '
            ';
         $comment .= 'Файл чертежа или примера: ' . $userData['file-upload'] . '
            ';
         $comment .= 'Размеры (В/Г/Д): ' . $userData['size'] . '
            ';
         $comment .= 'Материал столешницы: ' . $userData['material_stoleshnici'] . '
            ';
         $comment .= 'Тип дерева: ' . $userData['tip_dereva'] . '
            ';
         $comment .= 'Тип камня: ' . $userData['tip_kamnnya'] . '
            ';
         $comment .= 'Тип стекла: ' . $userData['tip_stekla'] . '
            ';
         $comment .= 'Цвет стекла: ' . $userData['glass_color'] . '
            ';
         $comment .= 'Фото принт: ' . $userData['photo_print'] . '
            ';
         $comment .= 'Цвет подстолья:(или индивидуальный если указан) ' . $userData['cvet_podstolya'] . '
            ';
         $comment .= 'Количество: ' . $userData['quantity'] . '
            ';
         $comment .= 'Доставка: ' . $userData['dostavka'] . '
            ';
         $comment .= 'Адрес доставки(если указан): ' . $userData['address'] . '
            ';
         $comment .= 'Монтаж: ' . $userData['montaj'] . '
            ';
         $comment .= 'Поместятся ли изделия в лифт, номер этажа и материал стен: ' . $userData['lift_steni'] . '
            ';
         break;
      case '17':
         $name = $userData['name'];
         $phone = $userData['phone'];
         $email = $userData['email'];
         $formname = "Другая категория: ";

         $comment .= 'Описание проекта: ' . $userData['description'] . '
            ';
         $comment .= 'Файл чертежа или примера: ' . $userData['file-upload'] . '
            ';
         $comment .= 'Доставка: ' . $userData['dostavka'] . '
            ';
         $comment .= 'Адрес доставки(если указан): ' . $userData['address'] . '
            ';
         $comment .= 'Монтаж: ' . $userData['montaj'] . '
            ';
         $comment .= 'Поместятся ли изделия в лифт, номер этажа и материал стен: ' . $userData['lift_steni'] . '
            ';
         break;
   }
   try {
      $amo = new \AmoCRM\Client($AMO_DOMAIN, $AMO_LOGIN, $AMO_HASH);
      $contact = $amo->contact->apiList(['query' => $email]);
      if ($contact == null) {
         $contact = $amo->contact;
         $contact->debug(false);
         $contact['name'] = $name;
         $contact->addCustomField(132085, [
            [$email, 'WORK'],
         ]);
         $contact->addCustomField(132081, [
            [$phone, 'WORK'],
         ]);
         $contact_id = $contact->apiAdd();
      } else {
         $contact_id = $contact[count($contact) - 1]['id'];
      }
      $lead = $amo->lead;
      $lead->debug(false);
      $lead['name'] = 'Заказ с сайта genglass.ru (' . $name . ')';
      $lead['price'] = $userData['price'];
      $lead_id = $lead->apiAdd();
      $links = $amo->links;
      $links['from'] = 'leads';
      $links['from_id'] = $lead_id;
      $links['to'] = 'contacts';
      $links['to_id'] = $contact_id;
      $links->apiLink();
      $note = $amo->note;
      $note->debug(false);
      $note['element_id'] = $lead_id;
      $note['element_type'] = \AmoCRM\Models\Note::TYPE_LEAD;
      $note['note_type'] = \AmoCRM\Models\Note::COMMON;
      $note['text'] = $comment;
      $id = $note->apiAdd();
   } catch (\AmoCRM\Exception $e) {
      set_log("Error ({$e->getCode()}): {$e->getMessage()}");
      printf('Error (%d): %s', $e->getCode(), $e->getMessage());
   }
}